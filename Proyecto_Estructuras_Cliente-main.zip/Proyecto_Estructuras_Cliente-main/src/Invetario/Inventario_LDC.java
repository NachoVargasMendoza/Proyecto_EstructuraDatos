package Invetario;

//Este clase esta pensada para crear un inventario donde se sumen 
//articulos y se resten cuando se compran cada articulo tiene x cantidad de unidades disponibles

/**
 *
 * @author mija2
 */
public class Inventario_LDC {
    
}

package Compra;

//Este clase esta pensada para crear un carrito de compra 

import Proyecto_Estructuras.Articulos;

//donde la crea un usuario e imprima lo comprado

/**
 *
 * @author mija2
 */
public class Compra_LSC {
    private Nodo_LSC inicio;
    private Nodo_LSC fin;
    private Articulos Datos;
    
    public Compra_LSC(){
        this.inicio=null;
        this.fin=null;
    }
    
    public boolean vacio(){
        if(inicio==null){
            return true;
            
        }else{
            return false;
        }
    }
    
    
}

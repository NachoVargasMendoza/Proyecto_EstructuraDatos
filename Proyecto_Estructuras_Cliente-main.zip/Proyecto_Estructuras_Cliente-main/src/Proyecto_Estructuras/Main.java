package Proyecto_Estructuras;


import AgregarInventario.VentanaAgregar;
import AgregarInventario.AgregarInvetario_Cola;
import javax.swing.JOptionPane;


public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        
        VentanaAgregar vn = new VentanaAgregar();
        vn.setVisible(true);
       
        
    }
    
}
